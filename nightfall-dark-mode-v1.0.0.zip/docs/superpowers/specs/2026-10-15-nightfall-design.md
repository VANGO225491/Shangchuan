# 夜览 · 浏览器暗色模式扩展

用户需求：在指定目录交付可独立运行的浏览器插件，让网站以暗色主题用于夜间和日常浏览。用户已确认 Chrome／Edge。

实现决定：Manifest V3，原生 HTML/CSS/JavaScript，无构建步骤、无运行时外部请求。使用本地捆绑的 Dark Reader MIT 引擎处理网页颜色、动态内容及媒体保护。界面为中文，品牌名「夜览」，深色卡片配薄荷绿强调色。

## 交付行为

- 默认对可访问的 HTTP、HTTPS 和获准的 file 页面开启暗色模式；浏览器内部页面、扩展商店及内置 PDF 等受浏览器限制的页面需说明限制。
- 全局开关与当前网站开关；网站规则按精确 hostname 保存，嵌入的跨域 iframe 跟随顶层网站规则。
- 始终开启／跟随系统两种模式；系统偏好实时生效。
- 柔和、深黑、暖夜三种预设；亮度 70–120、对比度 70–120、暖色 0–60，调整立即应用到已注入的页面。
- 设置仅存储在本机 chrome.storage.local；后台串行合并修改，避免多个窗口覆盖其他字段。
- 不采集浏览记录、不发送遥测；网页渲染可能读取页面原有的样式和图片资源以分析颜色。
- 打开弹窗时对当前可访问旧标签页尝试补充注入；其他安装前已打开的标签页刷新后生效。
- 提供 README 中文安装和故障说明、保留第三方许可、可解压安装的 zip。

## 文件边界

`extension/manifest.json` 扩展清单；`settings.js` 纯设置与策略函数；`background.js` 设置写入与顶层页面上下文；`content.js` 引擎生命周期；`popup.html/css/js` 控制台；`vendor/darkreader.js` 和 LICENSE 本地渲染引擎；`icons/` 图标。

## 接口

`globalThis.NightfallSettings` 暴露 `defaults`, `normalize(raw)`, `patch(current, changes)`, `hostname(url)`, `isSupported(url)`, `isActive(settings, host, systemDark)`, `theme(settings)`。

设置对象：`{ enabled: true, mode: 'always', brightness: 100, contrast: 100, sepia: 0, preset: 'soft', excludedHosts: [] }`。`preset` 为 `soft|deep|warm|custom`；`patch` 支持普通字段及 `site: {hostname, enabled}`、`reset: true`，并做数值范围验证。

后台消息：`GET_STATE` → `{ok:true, settings}`；`PATCH_SETTINGS` 的 `changes` → 同前；`GET_CONTEXT` → `{ok:true, hostname}`（优先 sender.tab.url）；错误返回 `{ok:false,error}`。存储键 `nightfallSettings`。

## 验证

Node 原生测试验证默认值、损坏数据、数值边界、站点规则、系统偏好和原型安全。Playwright 使用真实 Chromium 加载扩展，验证浅色网页变暗、图像不反色、动态内容、跨域 iframe、开关恢复、设置持久化、系统模式以及 popup 交互。用户无需 Node 即可安装使用；Node 仅用于开发验证。
