# Nightfall Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付可离线直接加载的中文 Chrome／Edge 暗色模式扩展。

**Architecture:** 本地 Dark Reader 引擎由内容脚本启停，后台管理本地设置及顶层站点上下文，popup 提供即时设置。纯设置模块与实际浏览器集成分别验证。

**Tech Stack:** Manifest V3、JavaScript、HTML、CSS、Node test、Playwright Chromium。

**Spec:** docs/superpowers/specs/2026-10-15-nightfall-design.md

## Global Constraints

- Chrome／Edge Manifest V3，无构建步骤、无运行时外部依赖。
- 本地存储、中文界面、保留 Dark Reader MIT 许可。
- 按 hostname 设置网站规则；iframe 跟随顶层网站；恢复页面时清除注入样式。

## Review Focus

- 损坏或越界的设置：归一化并限制范围。
- 多窗口同时写设置：后台串行合并。
- 顶层禁用站点含跨域 iframe：所有 frame 停用。
- 浏览器受限页和旧标签页：明确状态且补注入幂等。
- 跟随系统及刷新：暗色偏好与本机持久化均正确。

### Task 1: 设置和策略

**Files:** extension/settings.js, tests/settings.test.cjs

**Interfaces:** 遵守 spec 的 NightfallSettings 接口和字面默认值。

- [x] 先写默认值、数值边界、损坏值、精确 hostname、系统偏好及原型安全测试。
- [x] `node --test tests/settings.test.cjs`，先观察未实现导致失败。
- [x] 实现纯函数，重跑同一测试到通过。

### Task 2: 独立界面与本地引擎（可并行）

**Files:** extension/popup.html, extension/popup.css, extension/popup.js, extension/vendor/*, extension/icons/*, README.md

**Interfaces:** GET_STATE、PATCH_SETTINGS、GET_CONTEXT 与 settings 模块如 spec；页面元素使用可访问标签。

- [x] 本地获取固定版本引擎并保留许可，不添加运行时 CDN。
- [x] 实现紧凑中文 popup、预设、开关、slider、系统模式、当前域名和错误反馈。
- [x] 写中文安装步骤和权限／受限页说明，生成本地图标。

### Task 3: 扩展集成

**Files:** extension/manifest.json, extension/background.js, extension/content.js, tests/browser.test.cjs, package.json

**Interfaces:** 导入 settings.js；DarkReader.enable(theme)、disable()；chrome.storage.local 键 nightfallSettings。

- [x] 浏览器集成测试先覆盖真实浅色页面、动态节点、媒体和开关恢复；观察缺失扩展功能失败。
- [x] 实现消息写入队列、document_start 注入、storage 与 matchMedia 实时监听、顶层域名规则。
- [x] 增加跨域 iframe、持久化、popup 交互、系统切换与并发写入的浏览器验证。
- [x] `npm test` 通过，再由独立审查者审查；修复实际问题后完整重跑。
- [x] 打包 extension 到「夜览-浏览器暗色模式.zip」，解压清单验证内容齐全。

## Execution notes

指定目录为空且没有 Git 仓库，直接在用户指定目录创建，不迁移目录、不创建分支或提交。用户已授权创建完整插件，按上述默认方案持续实现，浏览器偏好已确认。界面和第三方文件可分别委派，核心与浏览器验证由主代理负责。

独立审查发现并修复：弹窗改为按 MIME 检查网页支持情况；设置请求即时发送至后台串行保存，避免关闭弹窗丢失尚未发送的修改。两项均先复现失败，再修复并验证。引擎关闭后保留的 Shadow DOM 空 style 不含规则，测试确认原有颜色恢复。

最终实现验证：`npm test` → 18 tests，18 pass，0 fail。实际 Chromium 工具栏弹窗交互、完整重启、并发写入、受 CSP 限制网页、图片和 Shadow DOM 均有行为验证。弹窗文档高度不超过 600px，预览截图人工检查完成。

交付 ZIP 包含 22 个文件，使用标准正斜杠条目；Manifest V3 及所有引用脚本／图标存在，捆绑引擎 SHA-256 与固定 npm 版本一致；所有 JavaScript 语法检查通过。
