const { test } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const extension = path.join(root, 'extension');
const sample = `<!doctype html><html><head><meta charset="utf-8"><title>夜览测试网页</title>
<style>html,body{background:#fff;color:#151515;margin:0;font:18px system-ui}body{padding:40px}.card{background:#f5f5f5;border:1px solid #ddd;padding:24px}a{color:#065bcc}input{background:#fff;color:#222}img{width:80px;height:80px}</style></head>
<body><h1>让网页，轻轻入夜。</h1><p>这是一张原本明亮的页面，用于验证文字、背景、链接与图像。</p>
<div class="card">动态暗色主题 <a href="#">保留清晰的链接</a> <input aria-label="输入框" placeholder="输入文字"></div>
<img alt="原色图片" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect width='80' height='80' fill='%23ef4444'/%3E%3C/svg%3E">
</body></html>`;
const dark = async (target, selector = 'body') => target.waitForFunction(sel => {
  const el = document.querySelector(sel);
  if (!el) return false;
  const channels = getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
  return channels && channels.length >= 3 && channels.slice(0,3).every(v => Number(v) < 110);
}, selector, {timeout:15000});
const light = async (target, selector = 'body') => target.waitForFunction(sel => {
  const el = document.querySelector(sel);
  if (!el) return false;
  const channels = getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
  return channels && channels.slice(0,3).every(v => Number(v) > 220);
}, selector, {timeout:15000});

// Chrome action popups are CDP targets but Playwright does not emit Page events for them.
// Attach to the actual toolbar popup instead of replacing the browser's tabs API.
async function openToolbar(context, worker, activePage) {
  const cdp=await context.newCDPSession(activePage);
  await worker.evaluate(()=>chrome.action.openPopup());
  const {targetInfos}=await cdp.send('Target.getTargets');
  const target=targetInfos.find(info=>info.url.endsWith('/popup.html'));
  assert.ok(target,'Toolbar popup target must exist');
  const {sessionId}=await cdp.send('Target.attachToTarget',{targetId:target.targetId,flatten:false});
  const pending=new Map();let seq=0;
  cdp.on('Target.receivedMessageFromTarget',event=>{
    if(event.sessionId!==sessionId)return;
    const message=JSON.parse(event.message);const operation=pending.get(message.id);
    if(!operation)return;
    pending.delete(message.id);clearTimeout(operation.timer);
    message.error ? operation.reject(new Error(message.error.message)) : operation.resolve(message.result);
  });
  const send=(method,params={})=>new Promise((resolve,reject)=>{
    const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(new Error(`Popup CDP timeout: ${method}`));},10000);
    pending.set(id,{resolve,reject,timer});
    cdp.send('Target.sendMessageToTarget',{sessionId,message:JSON.stringify({id,method,params})}).catch(reject);
  });
  const evaluate=async(fn,...args)=>{
    const reply=await send('Runtime.evaluate',{expression:`(${fn.toString()})(...${JSON.stringify(args)})`,returnByValue:true,awaitPromise:true});
    if(reply.exceptionDetails)throw new Error(reply.exceptionDetails.text);
    return reply.result.value;
  };
  const wait=async(fn)=>{
    const until=Date.now()+10000;
    while(Date.now()<until){if(await evaluate(fn))return;await new Promise(resolve=>setTimeout(resolve,50));}
    throw new Error('Popup condition timed out');
  };
  await wait(()=>document.readyState==='complete'&&!document.querySelector('#global-toggle').disabled);
  return {evaluate,wait,send,close:async()=>{await cdp.send('Target.closeTarget',{targetId:target.targetId});await cdp.detach();}};
}
async function openBackgroundPopup(context,worker,activePage){
  await activePage.bringToFront();
  const opened=context.waitForEvent('page');
  await worker.evaluate(()=>chrome.tabs.create({url:chrome.runtime.getURL('popup.html'),active:false}));
  const popup=await opened;await popup.waitForLoadState();
  await popup.waitForFunction(()=>!document.querySelector('#global-toggle').disabled);
  return popup;
}

test('real Chromium extension changes pages and restores them with persistent controls', {timeout:180000}, async t => {
  assert.ok(fs.existsSync(path.join(extension, 'manifest.json')), 'Browser extension has not been implemented');
  const server = http.createServer((req,res) => {
    res.setHeader('Content-Type','text/html; charset=utf-8');
    if(req.url==='/image'){res.setHeader('Content-Type','image/svg+xml');res.end('<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><rect width="50" height="50" fill="white"/></svg>');return;}
    if (req.url === '/strict') res.setHeader('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'");
    const port = server.address().port;
    res.end(req.url === '/frames' ? sample.replace('</body>',`<iframe title="嵌入页面" src="http://localhost:${port}/fixture"></iframe></body>`) : sample);
  });
  await new Promise(resolve => server.listen(0,'0.0.0.0',resolve));
  t.after(() => { server.closeAllConnections(); return new Promise(resolve=>server.close(resolve)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  fs.mkdirSync(path.join(root,'test-results'),{recursive:true});
  const profile = fs.mkdtempSync(path.join(root,'test-results','profile-'));
  const launch = () => chromium.launchPersistentContext(profile,{
    channel:'chromium',headless:true,colorScheme:'light',viewport:{width:1120,height:760},
    args:[`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]
  });
  let context = await launch();
  t.after(async()=>{
    await context.close();
    if (profile.startsWith(path.join(root,'test-results') + path.sep)) fs.rmSync(profile,{recursive:true,force:true});
  });
  let worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
  const id = new URL(worker.url()).host;
  // Extension pages are a real client of the worker; no chrome API mocking.
  let control = await context.newPage();
  await control.goto(`chrome-extension://${id}/manifest.json`);
  const message = (type,changes) => control.evaluate(({type,changes})=>chrome.runtime.sendMessage({type,changes}),{type,changes});
  const patch = async changes => {
    const result = await message('PATCH_SETTINGS',changes);
    assert.equal(result.ok,true,result.error);
    return result.settings;
  };
  await patch({reset:true});
  const page = await context.newPage();
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(`${base}/frames`);

  await t.test('white backgrounds become dark, readable text and media retain usable colors',async()=>{
    await dark(page);
    const frame = page.frames().find(f=>f.url().includes('localhost'));
    assert.ok(frame);
    await dark(frame);
    const result=await page.evaluate(()=>({
      text:getComputedStyle(document.body).color,
      image:getComputedStyle(document.querySelector('img')).filter,
      pageFilter:getComputedStyle(document.documentElement).filter,
      loaded:document.querySelector('img').naturalWidth
    }));
    assert.ok(result.text.match(/\d+/g).slice(0,3).every(v=>Number(v)>150),result.text);
    assert.equal(result.image,'none');
    assert.equal(result.pageFilter,'none');
    assert.equal(result.loaded,80);
    await page.screenshot({path:path.join(root,'test-results','webpage-dark.png')});
  });

  await t.test('new inline elements and shadow DOM receive dark styling',async()=>{
    await page.evaluate(()=>{
      const dynamic=document.createElement('div');dynamic.id='dynamic';dynamic.style.cssText='background:white;color:black';dynamic.textContent='新插入的内容';document.body.append(dynamic);
      const host=document.createElement('section');host.id='shadow';document.body.append(host);
      host.attachShadow({mode:'open'}).innerHTML='<style>div{background:#fff;color:#000;padding:20px}</style><div>Shadow DOM</div>';
    });
    await dark(page,'#dynamic');
    await page.waitForFunction(()=>{
      const color=getComputedStyle(document.querySelector('#shadow').shadowRoot.querySelector('div')).backgroundColor;
      return color.match(/\d+/g).slice(0,3).every(v=>Number(v)<110);
    });
  });

  await t.test('site exceptions disable every embedded frame without disabling another top-level hostname',async()=>{
    const sibling=await context.newPage();await sibling.goto(`http://localhost:${server.address().port}/fixture`);await dark(sibling);
    await patch({site:{hostname:'127.0.0.1',enabled:false}});
    await light(page);await light(page.frames().find(f=>f.url().includes('localhost')));
    await dark(sibling);
    await patch({site:{hostname:'127.0.0.1',enabled:true}});
    await dark(page);await dark(page.frames().find(f=>f.url().includes('localhost')));
    await sibling.close();
  });

  await t.test('global disable restores original colors and clears generated styles',async()=>{
    await patch({enabled:false});await light(page);await light(page,'#dynamic');
    // The engine may retain an empty inversion marker in a shadow root.
    // Only styles containing rules can affect the restored page.
    const remaining = await page.locator('style.darkreader').evaluateAll(nodes=>nodes.filter(n=>n.textContent.trim()).length);
    const restoredShadow = await page.evaluate(()=>getComputedStyle(document.querySelector('#shadow').shadowRoot.querySelector('div')).backgroundColor);
    assert.equal(restoredShadow,'rgb(255, 255, 255)');
    await page.screenshot({path:path.join(root,'test-results','webpage-original.png')});
    await patch({enabled:true});await dark(page);
    assert.equal(remaining,0);
  });

  await t.test('system mode reacts to live OS color preference',async()=>{
    await patch({mode:'system'});await light(page);
    await page.emulateMedia({colorScheme:'dark'});await dark(page);
    await page.emulateMedia({colorScheme:'light'});await light(page);
    await patch({mode:'always'});await dark(page);
  });

  await t.test('concurrent clients merge patches instead of overwriting unrelated settings',async()=>{
    const replies=await control.evaluate(()=>Promise.all([
      chrome.runtime.sendMessage({type:'PATCH_SETTINGS',changes:{brightness:85}}),
      chrome.runtime.sendMessage({type:'PATCH_SETTINGS',changes:{contrast:110}}),
      chrome.runtime.sendMessage({type:'PATCH_SETTINGS',changes:{site:{hostname:'example.com',enabled:false}}})
    ]));
    assert.ok(replies.every(r=>r.ok));
    const result=await message('GET_STATE');
    assert.equal(result.settings.brightness,85);assert.equal(result.settings.contrast,110);
    assert.deepEqual(result.settings.excludedHosts,['example.com']);
    await patch({preset:'warm'});await dark(page);
  });

  await t.test('strict page CSP still allows ordinary dark styling',async()=>{
    const strict=await context.newPage();await strict.goto(`${base}/strict`);await dark(strict);await strict.close();
  });

  await t.test('settings survive a complete browser restart',async()=>{
    await context.close();context=await launch();
    worker=context.serviceWorkers()[0]||await context.waitForEvent('serviceworker');
    control=await context.newPage();await control.goto(`chrome-extension://${id}/manifest.json`);
    const result=await message('GET_STATE');assert.equal(result.settings.preset,'warm');assert.equal(result.settings.sepia,30);
    const persisted=await context.newPage();await persisted.goto(`${base}/fixture`);await dark(persisted);
    await persisted.close();
  });

  await t.test('toolbar popup controls website, presets, sliders and reset',async()=>{
    assert.ok(fs.existsSync(path.join(extension,'popup.html')),'Popup controls have not been implemented');
    await patch({reset:true});
    const target=await context.newPage();await target.goto(`${base}/fixture`);await target.bringToFront();await dark(target);
    const popup=await openToolbar(context,worker,target);
    await popup.wait(()=>!document.querySelector('#site-toggle').disabled);
    assert.equal(await popup.evaluate(()=>document.querySelector('#global-toggle').checked),true);
    await popup.evaluate(()=>document.querySelector('#site-toggle').click());await light(target);
    await popup.evaluate(()=>document.querySelector('#site-toggle').click());await dark(target);
    await popup.evaluate(()=>document.querySelector('[data-preset="warm"]').click());
    await popup.wait(()=>document.querySelector('#sepia').value==='30');
    assert.equal((await message('GET_STATE')).settings.preset,'warm');
    await popup.evaluate(()=>{const node=document.querySelector('#brightness');node.value='80';node.dispatchEvent(new Event('input',{bubbles:true}));node.dispatchEvent(new Event('change',{bubbles:true}));});
    await control.waitForFunction(async()=> (await chrome.runtime.sendMessage({type:'GET_STATE'})).settings.brightness===80);
    assert.equal((await message('GET_STATE')).settings.preset,'custom');
    await popup.evaluate(()=>document.querySelector('#global-toggle').click());await light(target);
    await popup.evaluate(()=>document.querySelector('#global-toggle').click());await dark(target);
    await popup.evaluate(()=>document.querySelector('#reset-settings').click());
    await popup.wait(()=>document.querySelector('#brightness').value==='100'&&document.querySelector('#sepia').value==='0');
    assert.deepEqual((await message('GET_STATE')).settings.excludedHosts,[]);
    const bounds=await popup.evaluate(()=>({width:document.body.scrollWidth,height:document.documentElement.scrollHeight}));
    assert.ok(bounds.height<=600,`Popup content should fit the standard 600px limit, got ${bounds.height}`);
    const screenshot=await popup.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:bounds.width,height:bounds.height,scale:1}});
    fs.writeFileSync(path.join(root,'test-results','popup.png'),Buffer.from(screenshot.data,'base64'));
    assert.equal(await popup.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth),false,'Popup must not overflow horizontally');
    await popup.close();await target.close();
  });
  await t.test('popup identifies page content rather than filename extension',async()=>{
    const target=await context.newPage();
    for(const [pathname,supported] of [['/image',false],['/page.pdf',true]]){
      await target.goto(base+pathname);await target.bringToFront();
      const popup=await openBackgroundPopup(context,worker,target);
      await popup.waitForFunction(()=>!document.querySelector('#site-description').textContent.includes('正在检查'));
      const enabled=await popup.evaluate(()=>!document.querySelector('#site-toggle').disabled);
      await popup.close();
      assert.equal(enabled,supported,pathname);
    }
    await target.close();
  });
  await t.test('rapid changes remain saved when popup closes before replies arrive',async()=>{
    await patch({reset:true});
    const target=await context.newPage();await target.goto(`${base}/fixture`);
    const popup=await openBackgroundPopup(context,worker,target);
    await popup.evaluate(()=>{
      const input=document.querySelector('#global-toggle');
      input.checked=false;input.dispatchEvent(new Event('change',{bubbles:true}));
      input.checked=true;input.dispatchEvent(new Event('change',{bubbles:true}));
      window.close();
    }).catch(error=>{if(!/closed|destroyed/i.test(error.message))throw error;});
    const result=await message('GET_STATE');
    assert.equal(result.settings.enabled,true,'The final toggle must persist after popup closes');
    await target.close();
  });
  assert.deepEqual(errors,[],'Page JS errors');
});
