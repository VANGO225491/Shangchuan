const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const context = vm.createContext({ URL });
const path = require('node:path').join(__dirname, '../extension/settings.js');
if (fs.existsSync(path)) vm.runInContext(fs.readFileSync(path, 'utf8'), context);
const get = () => {
  assert.ok(context.NightfallSettings, 'Settings policy has not been implemented');
  return context.NightfallSettings;
};
const plain = value => JSON.parse(JSON.stringify(value));

test('new users get active, neutral dark mode and independent mutable settings', () => {
  const s = get();
  assert.deepEqual(plain(s.normalize()), {
    enabled: true, mode: 'always', brightness: 100, contrast: 100,
    sepia: 0, preset: 'soft', excludedHosts: []
  });
  const first = s.normalize();
  first.excludedHosts.push('example.com');
  assert.deepEqual(plain(s.normalize().excludedHosts), []);
});

test('damaged persisted settings fall back safely and numeric limits are enforced', () => {
  const s = get();
  assert.equal(s.normalize(null).enabled, true);
  assert.equal(s.normalize({enabled:'false'}).enabled, true);
  const data = s.normalize({mode:'night',brightness:500,contrast:-2,sepia:NaN,preset:'unknown',excludedHosts:42});
  assert.equal(data.mode, 'always');
  assert.equal(data.brightness, 120);
  assert.equal(data.contrast, 70);
  assert.equal(data.sepia, 0);
  assert.equal(data.preset, 'soft');
  assert.deepEqual(plain(data.excludedHosts), []);
  assert.equal(s.normalize({brightness:'80'}).brightness,100);
});

test('website exceptions are exact hostnames and handle unsafe keys as ordinary data', () => {
  const s = get();
  let settings = s.patch(s.normalize(), {site:{hostname:'EXAMPLE.com.',enabled:false}});
  assert.equal(s.isActive(settings,'example.com',false), false);
  assert.equal(s.isActive(settings,'sub.example.com',false), true);
  settings = s.patch(settings, {site:{hostname:'__proto__',enabled:false}});
  assert.equal(s.isActive(settings,'__proto__',false), false);
  assert.equal(s.isActive(settings,'constructor',false), true);
  settings = s.patch(settings, {site:{hostname:'example.com',enabled:true}});
  assert.equal(s.isActive(settings,'example.com',false), true);
  assert.equal(s.patch(settings,{site:{hostname:'a/b',enabled:false}}).excludedHosts.includes('a/b'),false);
});

test('global disable and system preference take priority over site permission', () => {
  const s = get();
  assert.equal(s.isActive(s.normalize(),'example.com',false),true);
  const system = s.patch(s.normalize(),{mode:'system'});
  assert.equal(s.isActive(system,'example.com',false),false);
  assert.equal(s.isActive(system,'example.com',true),true);
  assert.equal(s.isActive(s.patch(system,{enabled:false}),'example.com',true),false);
});

test('presets set useful parameters, manual adjustment becomes custom, reset clears exceptions', () => {
  const s = get();
  const warm = s.patch(s.normalize(),{preset:'warm'});
  assert.equal(warm.sepia,30);
  assert.equal(warm.brightness,95);
  assert.equal(s.patch(warm,{brightness:80}).preset,'custom');
  const reset = s.patch({...warm,enabled:false,excludedHosts:['example.com']},{reset:true});
  assert.deepEqual(plain(reset),plain(s.normalize()));
  const t = s.theme(s.patch(s.normalize(),{preset:'deep'}));
  assert.equal(t.mode,1);
  assert.equal(t.darkSchemeBackgroundColor,'#101114');
  assert.equal(t.contrast,105);
});

test('URL policy covers real pages and excludes browser and extension store pages', () => {
  const s = get();
  assert.equal(s.hostname('https://Example.com.:8443/a'),'example.com');
  assert.equal(s.hostname('file:///C:/demo.html'),'__local_files__');
  assert.equal(s.hostname('about:blank'),'');
  assert.equal(s.isSupported('https://example.com'),true);
  assert.equal(s.isSupported('http://localhost:3000'),true);
  assert.equal(s.isSupported('file:///C:/demo.html'),true);
  for (const url of ['chrome://settings','edge://extensions','about:blank','invalid','https://chromewebstore.google.com/detail/a','https://chrome.google.com/webstore/detail/a','https://microsoftedge.microsoft.com/addons/detail/a']) {
    assert.equal(s.isSupported(url),false,url);
  }
});
