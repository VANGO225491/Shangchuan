'use strict';
importScripts('settings.js');

const policy = globalThis.NightfallSettings;
const STORAGE_KEY = 'nightfallSettings';
// A single worker serializes read/modify/write, including requests from different popups.
let writes = Promise.resolve();
const read = async () => policy.normalize((await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY]);
const update = changes => {
  const operation = writes.then(async () => {
    const settings = policy.patch(await read(), changes);
    await chrome.storage.local.set({ [STORAGE_KEY]: settings });
    return settings;
  });
  writes = operation.catch(() => {});
  return operation;
};

chrome.runtime.onInstalled.addListener(() => {
  // Normalize existing settings on upgrade without resetting the user's choices.
  update({}).catch(error => console.error('夜览：无法保存设置', error));
});

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type === 'GET_CONTEXT') {
    respond({ ok: true, hostname: policy.hostname(sender.tab?.url || sender.url || '') });
    return false;
  }
  if (message?.type === 'GET_STATE' || message?.type === 'PATCH_SETTINGS') {
    const request = message.type === 'PATCH_SETTINGS'
      ? update(message.changes) : writes.then(read);
    request.then(settings => respond({ ok: true, settings }))
      .catch(() => respond({ ok: false, error: '无法读取或保存设置，请重新打开扩展后重试。' }));
    return true;
  }
  // Dark Reader's local API also emits internal messages. It handles its own fetches.
  return false;
});
