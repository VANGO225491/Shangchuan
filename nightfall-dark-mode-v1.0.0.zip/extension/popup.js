(() => {
  'use strict';
  const Settings = globalThis.NightfallSettings;
  const $ = id => document.getElementById(id);
  const ui = {
    global: $('global-toggle'), site: $('site-toggle'), host: $('site-host'),
    siteDescription: $('site-description'), mode: $('mode'), reset: $('reset-settings'),
    status: $('status-line'), statusLabel: $('status-label'), badge: $('status-badge'),
    error: $('error-message'), presetLabel: $('preset-label'),
    presets: [...document.querySelectorAll('[data-preset]')],
    sliders: ['brightness', 'contrast', 'sepia'].map($)
  };
  const systemTheme = matchMedia('(prefers-color-scheme: dark)');
  const presetNames = { soft: '柔和舒适', deep: '沉浸深黑', warm: '温暖夜色', custom: '自定义' };
  let confirmed = Settings.normalize();
  let loaded = false;
  let loadFailed = false;
  let pageReady = false;
  let pageSupported = false;
  let pageHost = '';
  let pageReason = '';
  let pending = [];
  let sliderTimer;
  let sliderChanges = {};

  function visibleSettings() {
    let state = confirmed;
    for (const changes of pending) state = Settings.patch(state, changes);
    return Settings.patch(state, sliderChanges);
  }

  function render() {
    const state = visibleSettings();
    const siteEnabled = !state.excludedHosts.includes(pageHost);
    const active = Settings.isActive(state, pageHost, systemTheme.matches);
    ui.global.checked = state.enabled;
    ui.global.disabled = !loaded;
    ui.site.checked = pageSupported && siteEnabled;
    ui.site.disabled = !loaded || !pageReady || !pageSupported;
    ui.mode.value = state.mode;
    ui.mode.disabled = !loaded;
    ui.reset.disabled = !loaded;
    ui.presetLabel.textContent = presetNames[state.preset];
    for (const button of ui.presets) {
      button.disabled = !loaded;
      button.setAttribute('aria-pressed', String(button.dataset.preset === state.preset));
    }
    for (const slider of ui.sliders) {
      const value = state[slider.id];
      slider.value = value;
      slider.disabled = !loaded;
      slider.style.setProperty('--progress', `${(value - Number(slider.min)) / (Number(slider.max) - Number(slider.min)) * 100}%`);
      slider.setAttribute('aria-valuetext', `${value}%`);
      const output = $(`${slider.id}-value`);
      output.replaceChildren(document.createTextNode(String(value)));
      const unit = document.createElement('span');
      unit.textContent = '%';
      output.append(unit);
    }
    ui.badge.classList.toggle('is-paused', !state.enabled || (state.mode === 'system' && !systemTheme.matches));
    ui.statusLabel.textContent = !loaded ? (loadFailed ? '连接中断' : '准备中') : !state.enabled ? '已暂停' : state.mode === 'system' && !systemTheme.matches ? '待机中' : '已开启';
    if (!loaded) ui.status.textContent = loadFailed ? '设置暂时不可用，请重新打开夜览。' : '正在载入你的浏览偏好…';
    else if (!state.enabled) ui.status.textContent = '已暂停暗色模式，随时可以再次开启。';
    else if (state.mode === 'system' && !systemTheme.matches) ui.status.textContent = '系统当前为浅色，切换深色后自动开启。';
    else if (pageReady && !pageSupported) ui.status.textContent = '夜览已就绪，将在可访问的网页上生效。';
    else if (pageReady && !siteEnabled) ui.status.textContent = '已为当前网站保留原来的色彩。';
    else ui.status.textContent = '暗色模式已就绪，享受舒适的浏览时光。';
    if (!pageReady) ui.siteDescription.textContent = '正在检查页面支持情况…';
    else if (!pageSupported) ui.siteDescription.textContent = pageReason;
    else if (!siteEnabled) ui.siteDescription.textContent = '此网站已关闭暗色模式';
    else if (!state.enabled) ui.siteDescription.textContent = '此网站已允许 · 全局开关已暂停';
    else if (!active) ui.siteDescription.textContent = '此网站已允许 · 等待系统深色';
    else ui.siteDescription.textContent = '此网站已开启暗色模式';
    document.querySelector('.site-card').classList.toggle('is-restricted', pageReady && !pageSupported);
  }

  function showError(message) {
    ui.error.textContent = message;
    ui.error.hidden = !message;
  }

  async function send(type, changes) {
    const response = await chrome.runtime.sendMessage(changes ? { type, changes } : { type });
    if (!response?.ok || !response.settings) throw new Error(response?.error || '扩展后台暂时无法响应');
    return Settings.normalize(response.settings);
  }

  function patch(changes) {
    if (!loaded) return;
    showError('');
    pending.push(changes);
    render();
    // Send immediately: the worker owns serialization and survives popup closure.
    // Keeping unsent changes in this document would lose them when it is closed.
    void send('PATCH_SETTINGS', changes).then(state => {
      confirmed = state;
    }).catch(() => {
      showError('未能保存这次调整，请重试。若问题持续，请重新打开夜览。');
    }).finally(() => {
      const index = pending.indexOf(changes);
      if (index !== -1) pending.splice(index, 1);
      render();
    });
  }

  function flushSliders() {
    clearTimeout(sliderTimer);
    const changes = sliderChanges;
    sliderChanges = {};
    if (Object.keys(changes).length) patch(changes);
  }

  function updateSettings(changes) {
    flushSliders();
    patch(changes);
  }

  async function inspectPage() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = tab?.url || tab?.pendingUrl || '';
      pageHost = Settings.hostname(url);
      const displayHost = pageHost === '__local_files__' ? '本地文件' : pageHost;
      ui.host.textContent = displayHost || '浏览器页面';
      ui.host.title = displayHost || '当前页面';
      pageSupported = !!tab?.id && Settings.isSupported(url);
      if (!pageSupported) {
        pageReason = '浏览器内部页面和扩展商店受保护，请打开普通网页使用。';
        return;
      }
      try {
        // Probe first: loading Dark Reader twice would create a second engine.
        const frames = await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          func: () => ({ injected: Boolean(globalThis.__nightfallInjected), contentType: document.contentType })
        });
        const top = frames.find(frame => frame.frameId === 0);
        if (!top) throw new Error('Page unavailable');
        const renderable = type => ['text/html', 'application/xhtml+xml'].includes(type);
        if (!renderable(top.result?.contentType)) {
          pageSupported = false;
          pageReason = top.result?.contentType === 'application/pdf'
            ? '内置 PDF 阅读器受浏览器限制，无法应用暗色模式。'
            : '此页面为独立图片或其他文档，请打开普通网页使用。';
          return;
        }
        const frameIds = frames.filter(frame => !frame.result?.injected && renderable(frame.result?.contentType)).map(frame => frame.frameId);
        if (frameIds.length) {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id, frameIds },
            files: ['settings.js', 'vendor/darkreader.js', 'content.js']
          });
        }
      } catch {
        pageSupported = false;
        pageReason = url.startsWith('file:')
          ? '请在扩展详情中允许访问文件网址，再重新打开。'
          : '此页面受浏览器限制或尚未载入，请刷新后重试。';
      }
    } catch {
      pageSupported = false;
      ui.host.textContent = '暂时无法识别页面';
      pageReason = '请打开普通网页，再重新打开夜览。';
    } finally {
      pageReady = true;
      render();
    }
  }

  ui.global.addEventListener('change', () => updateSettings({ enabled: ui.global.checked }));
  ui.site.addEventListener('change', () => {
    if (pageSupported) updateSettings({ site: { hostname: pageHost, enabled: ui.site.checked } });
  });
  ui.mode.addEventListener('change', () => updateSettings({ mode: ui.mode.value }));
  ui.reset.addEventListener('click', () => updateSettings({ reset: true }));
  for (const button of ui.presets) button.addEventListener('click', () => updateSettings({ preset: button.dataset.preset }));
  for (const slider of ui.sliders) {
    slider.addEventListener('input', () => {
      sliderChanges[slider.id] = Number(slider.value);
      render();
      clearTimeout(sliderTimer);
      sliderTimer = setTimeout(flushSliders, 60);
    });
    slider.addEventListener('change', flushSliders);
  }
  systemTheme.addEventListener('change', render);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.nightfallSettings) {
      confirmed = Settings.normalize(changes.nightfallSettings.newValue);
      render();
    }
  });
  window.addEventListener('pagehide', flushSliders);
  render();
  void inspectPage();
  void (async () => {
    try {
      confirmed = await send('GET_STATE');
      loaded = true;
      render();
    } catch {
      loadFailed = true;
      showError('未能读取设置，请关闭弹窗后重试。');
      render();
    }
  })();
})();
