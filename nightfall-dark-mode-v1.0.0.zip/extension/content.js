(() => {
  'use strict';
  if (globalThis.__nightfallInjected) return;
  globalThis.__nightfallInjected = true;
  if (document.contentType && !['text/html', 'application/xhtml+xml'].includes(document.contentType)) return;

  const policy = globalThis.NightfallSettings;
  const engine = globalThis.DarkReader;
  const system = matchMedia('(prefers-color-scheme: dark)');
  let settings = null;
  let host = null;
  let currentTheme = '';
  let active = false;
  let changesSeen = 0;

  // The bundled engine wraps runtime.sendMessage without returning its Promise.
  // Callback messaging works both with the native API and that wrapper.
  const request = message => new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, response => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (!response?.ok) {
        reject(new Error(response?.error || '扩展未响应'));
      } else resolve(response);
    });
  });
  engine.setFetchMethod(window.fetch.bind(window));

  function apply() {
    if (!settings || host === null) return;
    const enabled = policy.isActive(settings, host, system.matches);
    if (!enabled) {
      if (active) engine.disable();
      active = false;
      currentTheme = '';
      return;
    }
    const theme = policy.theme(settings);
    const signature = JSON.stringify(theme);
    if (!active || signature !== currentTheme) {
      engine.enable(theme);
      active = true;
      currentTheme = signature;
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.nightfallSettings) return;
    changesSeen++;
    settings = policy.normalize(changes.nightfallSettings.newValue);
    apply();
  });
  system.addEventListener('change', apply);
  const initialGeneration = changesSeen;
  Promise.all([request({ type: 'GET_STATE' }), request({ type: 'GET_CONTEXT' })])
    .then(([state, context]) => {
      if (initialGeneration === changesSeen) settings = policy.normalize(state.settings);
      host = context.hostname || policy.hostname(location.href);
      apply();
    })
    .catch(error => console.warn('夜览：初始化失败，请刷新页面。', error.message));
})();
