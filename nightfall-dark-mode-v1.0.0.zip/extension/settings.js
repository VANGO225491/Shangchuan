/* Shared by the service worker, content scripts and popup. No external dependencies. */
(() => {
  'use strict';
  const defaults = Object.freeze({
    enabled: true, mode: 'always', brightness: 100, contrast: 100,
    sepia: 0, preset: 'soft', excludedHosts: Object.freeze([])
  });
  const presets = Object.freeze({
    soft: { brightness: 100, contrast: 100, sepia: 0 },
    deep: { brightness: 100, contrast: 105, sepia: 0 },
    warm: { brightness: 95, contrast: 95, sepia: 30 }
  });
  const clamp = (value, min, max, fallback) => typeof value === 'number' && Number.isFinite(value)
    ? Math.round(Math.min(max, Math.max(min, value))) : fallback;
  const cleanHost = value => {
    if (typeof value !== 'string') return '';
    const host = value.trim().toLowerCase().replace(/\.$/, '');
    return host && !/[\s/\\?#@]/.test(host) && host.length <= 253 ? host : '';
  };
  function normalize(raw) {
    const data = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    return {
      enabled: typeof data.enabled === 'boolean' ? data.enabled : defaults.enabled,
      mode: data.mode === 'system' ? 'system' : 'always',
      brightness: clamp(data.brightness, 70, 120, 100),
      contrast: clamp(data.contrast, 70, 120, 100),
      sepia: clamp(data.sepia, 0, 60, 0),
      preset: ['soft', 'deep', 'warm', 'custom'].includes(data.preset) ? data.preset : 'soft',
      excludedHosts: [...new Set((Array.isArray(data.excludedHosts) ? data.excludedHosts : []).map(cleanHost).filter(Boolean))]
    };
  }
  function patch(current, changes) {
    const next = normalize(current);
    if (!changes || typeof changes !== 'object') return next;
    if (changes.reset === true) return normalize();
    for (const field of ['enabled', 'mode', 'brightness', 'contrast', 'sepia']) {
      if (Object.prototype.hasOwnProperty.call(changes, field)) next[field] = changes[field];
    }
    if (Object.prototype.hasOwnProperty.call(presets, changes.preset)) {
      Object.assign(next, presets[changes.preset]);
      next.preset = changes.preset;
    } else if (['brightness', 'contrast', 'sepia'].some(key => Object.prototype.hasOwnProperty.call(changes, key))) {
      next.preset = 'custom';
    }
    if (changes.site && typeof changes.site.enabled === 'boolean') {
      const host = cleanHost(changes.site.hostname);
      if (host) {
        next.excludedHosts = next.excludedHosts.filter(item => item !== host);
        if (!changes.site.enabled) next.excludedHosts.push(host);
      }
    }
    return normalize(next);
  }
  function hostname(url) {
    try {
      const parsed = new URL(url);
      if (parsed.protocol === 'file:') return '__local_files__';
      return ['http:', 'https:'].includes(parsed.protocol) ? cleanHost(parsed.hostname) : '';
    } catch { return ''; }
  }
  function isSupported(url) {
    try {
      const parsed = new URL(url);
      if (!['http:', 'https:', 'file:'].includes(parsed.protocol)) return false;
      const host = parsed.hostname.toLowerCase();
      if (host === 'chromewebstore.google.com') return false;
      if (host === 'chrome.google.com' && /^\/webstore(?:\/|$)/.test(parsed.pathname)) return false;
      if (host === 'microsoftedge.microsoft.com' && /^\/addons(?:\/|$)/.test(parsed.pathname)) return false;
      return true;
    } catch { return false; }
  }
  function isActive(settings, host, systemDark) {
    const data = normalize(settings);
    return data.enabled && (data.mode === 'always' || !!systemDark) && !data.excludedHosts.includes(cleanHost(host));
  }
  function theme(settings) {
    const data = normalize(settings);
    return {
      mode: 1, brightness: data.brightness, contrast: data.contrast, sepia: data.sepia,
      darkSchemeBackgroundColor: data.preset === 'deep' ? '#101114' : data.preset === 'warm' ? '#201b18' : '#181c23',
      darkSchemeTextColor: data.preset === 'warm' ? '#e5d9c8' : '#e3e6ed'
    };
  }
  globalThis.NightfallSettings = Object.freeze({ defaults, normalize, patch, hostname, isSupported, isActive, theme });
})();
